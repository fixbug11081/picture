import React from "react";
import Entry from "./Entry";
import emojipedias from "../emojipedia";

function createEmoji(emojipedia) {
  return (
    <Entry
      key={emojipedia.id}
      name={emojipedia.name}
      id={emojipedia.id}
      emoji={emojipedia.emoji}
      meaning={emojipedia.meaning}
    />
  );
}
function App() {
  return (
    <div>
      <h1>
        <span>emojipedia</span>
      </h1>
      <dl className="dictionary">{emojipedias.map(createEmoji)}</dl>
    </div>
  );
}

export default App;
