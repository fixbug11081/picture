import React from "react";

function Detail(props) {
  return (
    <div>
      <p className="info">{props.detailinfo}</p>
    </div>
  );
}
export default Detail;
